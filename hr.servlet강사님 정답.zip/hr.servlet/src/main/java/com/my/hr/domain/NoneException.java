package com.my.hr.domain;

public class NoneException extends RuntimeException {
	public NoneException(String msg) {
		super(msg);
	}
}
